import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/themes/app_colors.dart';

class CvChatActionBar extends StatelessWidget {
  const CvChatActionBar({
    required this.isGenerating,
    required this.canGenerate,
    required this.onGenerate,
    super.key,
  });

  final bool isGenerating;
  final bool canGenerate;
  final VoidCallback onGenerate;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: 16.w,
        vertical: 7.h,
      ),
      color: Colors.white,
      child: Align(
        alignment: Alignment.centerRight,
        child: TextButton.icon(
          onPressed:
          isGenerating || !canGenerate
              ? null
              : onGenerate,
          icon:
          isGenerating
              ? SizedBox(
            width: 18.w,
            height: 18.w,
            child: const CircularProgressIndicator(
              strokeWidth: 2,
            ),
          )
              : const Icon(
            Icons.auto_awesome_rounded,
          ),
          label: Text(
            isGenerating
                ? 'Generating...'
                : 'Generate CV',
          ),
          style: TextButton.styleFrom(
            foregroundColor: AppColors.primaryGreen,
            textStyle: const TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}