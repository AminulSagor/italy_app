import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:italir_pothe/core/widgets/custom_button.dart';
import 'package:italir_pothe/core/models/learning_activity_models.dart';
import 'package:italir_pothe/core/widgets/learning_activity_page_scope.dart';

import '../../../core/themes/app_colors.dart';
import '../../../core/themes/app_constants.dart';
import '../controllers/webinar_controller.dart';
import '../models/webinar_models.dart';
import '../widgets/webinar_live_widgets.dart';
import '../widgets/webinar_stage_widgets.dart';

class WebinarLiveView extends GetView<WebinarController> {
  const WebinarLiveView({super.key});

  @override
  Widget build(BuildContext context) {
    return LearningActivityPageScope(
      activityKind: LearningActivityKind.webinar,
      sourceId: 'webinar_live_view',
      child: PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) async {
        if (didPop) return;
        final bool shouldPop = await controller.onWillPopLive();
        if (shouldPop) Get.back<void>();
      },
      child: Scaffold(
        backgroundColor: AppColors.homeBackground,
        body: SafeArea(
          child: Obx(() {
            final WebinarItemModel? data = controller.selectedWebinar.value;
            if (data == null) {
              return const Center(
                child: CircularProgressIndicator(color: AppColors.primaryGreen),
              );
            }

            final bool keyboardVisible =
                MediaQuery.viewInsetsOf(context).bottom > 0;

            return Padding(
              padding: EdgeInsets.fromLTRB(
                kWebinarHorizontalPadding.w,
                10.h,
                kWebinarHorizontalPadding.w,
                keyboardVisible ? 0 : 20.h,
              ),
              child: controller.isParticipating.value
                  ? _ParticipationBody(
                data: data,
                controller: controller,
              )
                  : _ChatBody(
                data: data,
                controller: controller,
                keyboardVisible: keyboardVisible,
              ),
            );
          }),
        ),
      ),
    ),
    );
  }
}

class _ChatBody extends StatelessWidget {
  const _ChatBody({
    required this.data,
    required this.controller,
    required this.keyboardVisible,
  });

  final WebinarItemModel data;
  final WebinarController controller;
  final bool keyboardVisible;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (
          BuildContext context,
          BoxConstraints constraints,
          ) {
        final bool compactLayout =
            constraints.maxHeight < 560.h;

        return Stack(
          clipBehavior: Clip.none,
          children: <Widget>[
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                WebinarLiveHeader(
                  webinar: data,
                  controller: controller,
                ),

                SizedBox(
                  height: compactLayout ? 10.h : 20.h,
                ),

                WebinarVideoCard(
                  webinar: data,
                  controller: controller,
                ),

                SizedBox(
                  height: compactLayout ? 10.h : 16.h,
                ),

                Obx(
                      () => WebinarRequestButton(
                    text: _requestButtonText(),
                    icon: Icons.mic_rounded,
                    isDisabled:
                    controller.isSpeakerPending ||
                        controller.isRequesting.value,
                    onTap: controller.requestToParticipate,
                  ),
                ),

                if (!compactLayout && !keyboardVisible) ...<Widget>[
                  SizedBox(height: 16.h),
                  Expanded(
                    child: WebinarLiveChatSection(
                      controller: controller,
                    ),
                  ),
                  SizedBox(height: 14.h),
                ] else
                  const Spacer(),

                WebinarChatInput(
                  controller: controller,
                ),
              ],
            ),

            // Floating transparent comments above the keyboard/input.
            if (keyboardVisible)
              Positioned(
                left: 8.w,
                right: 8.w,
                bottom: 78.h,
                child: IgnorePointer(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      maxHeight: 175.h,
                    ),
                    child: WebinarLiveChatSection(
                      controller: controller,
                      compact: true,
                      showTitle: false,
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  String _requestButtonText() {
    if (controller.isRequesting.value) {
      return 'requesting'.tr;
    }

    if (controller.isSpeakerPending) {
      return 'pending'.tr;
    }

    if (controller.isSpeakerGranted) {
      return 'approved'.tr;
    }

    return 'request_to_participate'.tr;
  }
}

class _ParticipationBody extends StatelessWidget {
  const _ParticipationBody({required this.data, required this.controller});

  final WebinarItemModel data;
  final WebinarController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        WebinarLiveHeader(webinar: data, controller: controller),
        SizedBox(height: 18.h),
        WebinarVideoCard(webinar: data, controller: controller),
        SizedBox(height: 18.h),
        Expanded(child: WebinarStageArea(controller: controller)),
        SizedBox(height: 18.h),
        WebinarStageControls(controller: controller),
        SizedBox(height: 18.h),
        Obx(
          () => CustomButton(
            onPressed:
                controller.isLeaving.value ? () {} : controller.stopParticipation,
            isLoading: controller.isLeaving.value,
            text: controller.isLeaving.value
                ? 'leaving_stage'.tr
                : 'stop_and_leave_the_stage'.tr,
            btnColor: AppColors.white,
            textColor: AppColors.profileRedText,
            borderColor: AppColors.profileRedText,
            fontSize: 16.sp,
            icon: Icons.logout,
          ),
        ),
      ],
    );
  }
}
